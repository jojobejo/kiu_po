<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Role Access</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Role Access</li>
                    </ol>
                </div>
            </div>

            <?php foreach (array('success' => 'success', 'error' => 'danger') as $flashKey => $alertClass) : ?>
                <?php if ($this->session->flashdata($flashKey)) : ?>
                    <div class="alert alert-<?= $alertClass ?> alert-dismissible fade show" role="alert">
                        <?= html_escape($this->session->flashdata($flashKey)) ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>

            <?php if (!$table_ready) : ?>
                <div class="alert alert-warning">
                    <strong>Tabel permission belum tersedia.</strong>
                    Sistem masih memakai default role bawaan. Jalankan SQL <code>database/sql/role_permissions_20260909.sql</code> agar perubahan checkbox dapat disimpan.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <?php echo form_open('role-access/save'); ?>
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title mb-0">Matrix Module, Fungsi, Tombol</h3>
                        <button type="submit" class="btn btn-primary btn-sm ml-auto" <?= $table_ready ? '' : 'disabled' ?>>
                            <i class="fas fa-save"></i> Simpan Matrix
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-sm">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Module</th>
                                        <th>Fungsi</th>
                                        <th>Tombol / Aksi</th>
                                        <th>Permission Key</th>
                                        <?php foreach ($roles as $roleLevel => $roleLabel) : ?>
                                            <th class="text-center">
                                                <span class="d-block">Lv <?= html_escape($roleLevel) ?></span>
                                                <small><?= html_escape($roleLabel) ?></small>
                                            </th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($catalog as $permission) : ?>
                                        <?php $permissionKey = $permission['permission_key']; ?>
                                        <tr>
                                            <td>
                                                <strong><?= html_escape($permission['module_label']) ?></strong>
                                                <div><small class="text-muted"><?= html_escape($permission['module_key']) ?></small></div>
                                            </td>
                                            <td>
                                                <?= html_escape($permission['function_label']) ?>
                                                <div><small class="text-muted"><?= html_escape($permission['function_key']) ?></small></div>
                                            </td>
                                            <td>
                                                <?= html_escape($permission['button_label']) ?>
                                                <div><small class="text-muted"><?= html_escape($permission['permission_label']) ?></small></div>
                                            </td>
                                            <td><code><?= html_escape($permissionKey) ?></code></td>
                                            <?php foreach ($roles as $roleLevel => $roleLabel) : ?>
                                                <?php
                                                $checked = !empty($matrix[$permissionKey][$roleLevel]);
                                                $locked = po_permission_locked($permission, $roleLevel);
                                                ?>
                                                <td class="text-center">
                                                    <div class="custom-control custom-switch d-inline-block">
                                                        <input
                                                            type="checkbox"
                                                            class="custom-control-input"
                                                            id="permission_<?= html_escape(md5($permissionKey . '_' . $roleLevel)) ?>"
                                                            name="permissions[<?= html_escape($permissionKey) ?>][<?= html_escape($roleLevel) ?>]"
                                                            value="1"
                                                            <?= $checked ? 'checked' : '' ?>
                                                            <?= $locked || !$table_ready ? 'disabled' : '' ?>>
                                                        <label class="custom-control-label" for="permission_<?= html_escape(md5($permissionKey . '_' . $roleLevel)) ?>"></label>
                                                    </div>
                                                    <?php if ($locked) : ?>
                                                        <div><small class="text-muted">locked</small></div>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <small class="text-muted">
                            Checkbox mengatur hak akses per role. Aturan status, PIC pemilik request, dan departemen KADEP tetap dicek di backend sebagai pengaman workflow.
                        </small>
                    </div>
                    <div class="card-footer text-right">
                        <button type="submit" class="btn btn-primary" <?= $table_ready ? '' : 'disabled' ?>>
                            <i class="fas fa-save"></i> Simpan Matrix
                        </button>
                    </div>
                </div>
            <?php echo form_close(); ?>
        </div>
    </section>
</div>
