<?php
if (!function_exists('pojasa_preview_h')) {
    function pojasa_preview_h($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

$previewType = isset($preview['type']) ? $preview['type'] : 'embed';
$rows = isset($preview['rows']) && is_array($preview['rows']) ? $preview['rows'] : array();
$content = isset($preview['content']) ? (string) $preview['content'] : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= pojasa_preview_h($file_name) ?> - Preview Dokumen</title>
    <link rel="stylesheet" href="<?= base_url('assets/plugins/fontawesome-free/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/dist/css/adminlte.min.css') ?>">
    <style>
        body {
            background: #f4f6f9;
        }

        .preview-shell {
            min-height: 100vh;
            padding: 24px;
        }

        .preview-card {
            background: #fff;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            min-height: calc(100vh - 48px);
        }

        .preview-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 16px;
            border-bottom: 1px solid #dee2e6;
        }

        .preview-title {
            min-width: 0;
        }

        .preview-title h4 {
            margin: 0;
            font-size: 18px;
            word-break: break-word;
        }

        .preview-body {
            padding: 16px;
        }

        .preview-frame {
            width: 100%;
            height: calc(100vh - 155px);
            border: 1px solid #dee2e6;
            border-radius: 4px;
            background: #fff;
        }

        .preview-text {
            white-space: pre-wrap;
            word-break: break-word;
            min-height: calc(100vh - 180px);
            padding: 16px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            background: #fff;
            font-family: Menlo, Consolas, monospace;
            font-size: 13px;
            line-height: 1.55;
        }

        .preview-table-wrap {
            max-height: calc(100vh - 170px);
            overflow: auto;
            border: 1px solid #dee2e6;
            border-radius: 4px;
        }

        .preview-table {
            margin-bottom: 0;
            background: #fff;
        }

        .preview-table td,
        .preview-table th {
            white-space: nowrap;
            font-size: 13px;
        }

        @media (max-width: 767.98px) {
            .preview-shell {
                padding: 10px;
            }

            .preview-toolbar {
                align-items: stretch;
                flex-direction: column;
            }

            .preview-toolbar .btn-group,
            .preview-toolbar .btn {
                width: 100%;
            }

            .preview-frame {
                height: calc(100vh - 240px);
            }
        }
    </style>
</head>
<body>
    <div class="preview-shell">
        <div class="preview-card">
            <div class="preview-toolbar">
                <div class="preview-title">
                    <h4><?= pojasa_preview_h($file_name) ?></h4>
                    <small class="text-muted">
                        <?= pojasa_preview_h($request->kd_po_jasa) ?> | <?= pojasa_preview_h(strtoupper($file_ext)) ?>
                    </small>
                </div>
                <div class="btn-group">
                    <a href="<?= base_url('pojasa/detail/' . $request->kd_po_jasa) ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                    <a href="<?= pojasa_preview_h($file_url) ?>" class="btn btn-info" target="_blank">
                        <i class="fas fa-external-link-alt"></i> File Asli
                    </a>
                    <a href="<?= pojasa_preview_h($download_url) ?>" class="btn btn-primary">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            </div>
            <div class="preview-body">
                <?php if ($previewType === 'table') : ?>
                    <?php if (empty($rows)) : ?>
                        <div class="alert alert-light mb-0">Data dokumen tidak dapat ditampilkan.</div>
                    <?php else : ?>
                        <div class="preview-table-wrap">
                            <table class="table table-sm table-bordered preview-table">
                                <tbody>
                                    <?php foreach ($rows as $rowIndex => $row) : ?>
                                        <tr>
                                            <?php foreach ($row as $cell) : ?>
                                                <?php if ($rowIndex === 0) : ?>
                                                    <th><?= pojasa_preview_h($cell) ?></th>
                                                <?php else : ?>
                                                    <td><?= pojasa_preview_h($cell) ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                <?php elseif ($previewType === 'text') : ?>
                    <?php if (trim($content) === '') : ?>
                        <div class="alert alert-light mb-0">Isi dokumen tidak dapat diekstrak. Silakan buka file asli atau download dokumen.</div>
                    <?php else : ?>
                        <div class="preview-text"><?= pojasa_preview_h($content) ?></div>
                    <?php endif; ?>
                <?php elseif ($previewType === 'message') : ?>
                    <div class="alert alert-light mb-0"><?= pojasa_preview_h($content) ?></div>
                <?php else : ?>
                    <iframe src="<?= pojasa_preview_h($file_url) ?>" class="preview-frame"></iframe>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
