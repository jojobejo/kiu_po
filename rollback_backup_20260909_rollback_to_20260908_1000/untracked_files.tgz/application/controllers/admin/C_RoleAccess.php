<?php
defined('BASEPATH') or exit('No direct script access allowed');

class C_RoleAccess extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function index()
    {
        require_super_admin();

        $data = array(
            'title' => 'Role Access',
            'roles' => po_role_labels(),
            'catalog' => po_permission_catalog(),
            'table_ready' => po_permission_table_ready(),
            'matrix' => $this->permissionMatrix(),
        );

        $this->load->view('partial/header', $data);
        $this->load->view('partial/sidebar');
        $this->load->view('content/admin/role_access', $data);
        $this->load->view('partial/footer');
    }

    public function save()
    {
        require_super_admin();

        if (!po_permission_table_ready()) {
            $this->session->set_flashdata('error', 'Tabel tbpo_role_permission belum tersedia. Jalankan database/sql/role_permissions_20260909.sql terlebih dahulu.');
            redirect('role-access');
            return;
        }

        $posted = $this->input->post('permissions');
        if (!is_array($posted)) {
            $posted = array();
        }

        $roles = po_role_labels();
        $catalog = po_permission_catalog();

        $this->db->trans_begin();
        foreach ($catalog as $permission) {
            $permissionKey = $permission['permission_key'];

            foreach ($roles as $roleLevel => $roleLabel) {
                $allowed = isset($posted[$permissionKey][$roleLevel]);
                if (po_permission_locked($permission, $roleLevel)) {
                    $allowed = true;
                }

                $data = array(
                    'module_key' => $permission['module_key'],
                    'function_key' => $permission['function_key'],
                    'button_key' => $permission['button_key'],
                    'permission_key' => $permissionKey,
                    'role_level' => (string) $roleLevel,
                    'is_allowed' => $allowed ? 1 : 0,
                    'updated_by' => $this->session->userdata('kode'),
                    'updated_at' => date('Y-m-d H:i:s'),
                );

                $existing = $this->db
                    ->where('permission_key', $permissionKey)
                    ->where('role_level', (string) $roleLevel)
                    ->get('tbpo_role_permission')
                    ->row();

                if ($existing) {
                    $this->db
                        ->where('permission_key', $permissionKey)
                        ->where('role_level', (string) $roleLevel)
                        ->update('tbpo_role_permission', $data);
                } else {
                    $data['created_by'] = $this->session->userdata('kode');
                    $data['created_at'] = date('Y-m-d H:i:s');
                    $this->db->insert('tbpo_role_permission', $data);
                }
            }
        }

        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            $this->session->set_flashdata('error', 'Matrix role access gagal disimpan.');
            redirect('role-access');
            return;
        }

        $this->db->trans_commit();
        $this->session->set_flashdata('success', 'Matrix role access berhasil disimpan.');
        redirect('role-access');
    }

    private function permissionMatrix()
    {
        $matrix = array();
        foreach (po_permission_catalog() as $permission) {
            $permissionKey = $permission['permission_key'];
            $matrix[$permissionKey] = array();

            foreach (po_role_labels() as $roleLevel => $roleLabel) {
                $matrix[$permissionKey][$roleLevel] = po_permission_allowed_for_role($permissionKey, $roleLevel);
            }
        }

        return $matrix;
    }
}
