<!-- jQuery -->
<script src="<?php base_url('assets/plugins/jquery/jquery.min.js') ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php base_url('assets/plugins/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php base_url('assets/dist/js/adminlte.min.js') ?>"></script>
</body>

</html>